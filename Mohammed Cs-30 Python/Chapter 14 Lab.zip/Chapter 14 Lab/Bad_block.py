import pygame
import random
import Library_block

class bad(Library_block.Block):
    def update(self):
    # Move the block down one pixel
        self.rect.y += 1
        if self.rect.y > 400:
            self.rect.y = random.randrange(-100, -10)
            self.rect.x = random.randrange(0, 700)
import pygame
import random
import Library_block

WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
screen_width = 700
screen_height = 400
screen = pygame.display.set_mode([screen_width, screen_height])

def number_2():
    
    font = pygame.font.Font(None, 36)

    text = font.render("Instructions:", True, BLUE)
    screen.blit(text, [10, 20])
 
    text = font.render("There are 5 Levels. Collect all the green blocks.", True, WHITE)
    screen.blit(text, [10, 60])

    text = font.render("Destory the red blocks by aiming your mouse and clicking", True, WHITE)
    screen.blit(text, [10, 80])       

    text = font.render("to shoot bullets. Move with the arrow keys.", True, WHITE)
    screen.blit(text, [10, 100])   

    text = font.render("You have 3 lives. GOOD LUCK!", True, WHITE)
    screen.blit(text, [10, 120]) 
                
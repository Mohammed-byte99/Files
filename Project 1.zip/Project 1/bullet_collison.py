import pygame
import random
import Library_block
import bul

bad_block_list = pygame.sprite.Group()
bullet_list = pygame.sprite.Group()
all_sprites_list = pygame.sprite.Group()
 

def b_collison():
    for bullet in bullet_list:
        
        block_hit_list3 = pygame.sprite.spritecollide(bullet, bad_block_list , True)
        
        # For each block hit, remove the bullet and add to the score
        for block in block_hit_list3:
            bullet_list.remove(bullet)
            all_sprites_list.remove(bullet)
            score += 1
            print(score)
 
        # Remove the bullet if it flies up off the screen
        if bullet.rect.y < -10:
            bullet_list.remove(bullet)
            all_sprites_list.remove(bullet)



import pygame
import random
import Library_block
import bul
import player

click_sound = pygame.mixer.Sound('good.wav')
click_sound2 = pygame.mixer.Sound('bad.wav')

score = 0
good_block_list = pygame.sprite.Group()
bad_block_list = pygame.sprite.Group()
bullet_list = pygame.sprite.Group()
all_sprites_list = pygame.sprite.Group()

blocks_hit_list = pygame.sprite.spritecollide(player.Player(), good_block_list, True)
blocks_hit_list2 = pygame.sprite.spritecollide(player.Player(), bad_block_list, True)

def collison():
    
    # Check the list of collisions.
    for block in blocks_hit_list:
        click_sound.play()
        score += 1
        print(score)
    for block in blocks_hit_list2:
        click_sound2.play() 
        score -= 1
        print(score)



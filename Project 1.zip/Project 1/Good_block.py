import pygame
import random
import Library_block

class good(Library_block.Block):
    def update(self):
    # Move the block down one pixel
        self.rect.x += random.randrange(-1, 2)
        self.rect.y += random.randrange(-1, 2)
       
        
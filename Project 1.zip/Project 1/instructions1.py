import pygame
import random
import Library_block

RED   = (255,   0,   0)
GREEN = (0, 255, 0)
screen_width = 700
screen_height = 400
screen = pygame.display.set_mode([screen_width, screen_height])

def number_1():
    
    font = pygame.font.Font(None, 36)

    text = font.render("Welcome to Block Shooter!", True, GREEN)
    screen.blit(text, [175, 150])
 
    text = font.render("Click Your Mouse to Continue!", True, RED)
    screen.blit(text, [175, 200])
 